// TODO: Put a real interfaces here

export interface ITodo {
  id?: string
  name: string
  description: string
  isPrivate: boolean
  isCompleted?: boolean
}
